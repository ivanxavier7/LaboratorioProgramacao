## Encoding
Comando:
javac -encoding UTF8 src/*

## Run
java -cp . App

